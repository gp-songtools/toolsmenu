---
name: suno-from-spec
description: Make a Suno song, cover or loop from a song spec file, asking about each Suno setting, showing the exact request for approval, then returning playable results.
---

# Suno from a song spec

Use this when the user attaches a song spec (a `.songspec.md` file) or asks to make a song, cover or loop in Suno from one. The spec format is the one in github.com/gp-songtools/toolsmenu/blob/main/songspec/SPEC.md: settings as `key: value` lines between `---` lines at the top, then `## ` sections. Lines like `<!-- song-spec: ... -->` are bookkeeping. Ignore them and never send them.

The Suno tools are the Suno connector's (`audio-create`, `audio-covers-create`, `sounds-create`, `audio-retrieve`, `audio-wait`, `account-usage`). If they are deferred, load them with ToolSearch first.

## 1. Read the spec

Read the attached file. Headings match regardless of letter case. List what you found in two or three lines: title, bpm, key, request type, which sections have content. Do not paste the whole file back.

Settings (empty means not set): `request` (song, cover or sound; empty means song), `title`, `model`, `instrumental`, `voice_id`, `vocal_gender`, `weirdness`, `style_influence`, `variety`, `audio_influence`, `duration`, `max_mode`, `cover_source`, `loop`, `bpm`, `key`.

Sections: Style, Negative style, Lyrics, Sound are the only ones that can be sent. Never send Idea, Idea structure, Reference (never send to Suno), Analysis, Structure, Stems or Notes. Never put any artist or song name from Reference anywhere in the request. If one appears in the Style, Lyrics, title or description, stop and tell the user which field to fix.

## 2. Pick the request type

- song: `audio-create`
- cover: `audio-covers-create`, with `id` = the `cover_source` setting (required)
- sound or loop: `sounds-create`, with `description` = the Sound section, plus `loop` if set

If the user asks for a loop and the spec has no Sound section, ask them for a description of up to 500 characters. Do not use the Style text unless it fits in 500 characters and the user agrees.

## 3. Ask about the settings

First ask one question with AskUserQuestion: "How do you want to set the Suno options?" with these choices:
- Use the spec's values and leave the rest to Suno's defaults
- Go through each setting with me
- Suggest settings for me

If they choose to go through each setting, ask in batches of up to four questions, showing the spec's current value for each, and let them type an exact value with Other:

1. Tempo and key: keep the spec's, or change (ask for the new value). Key is a note plus major or minor.
2. Vocal gender: Auto, male or female. Not allowed together with a `voice_id`.
3. Duration: Auto, or a length from 15 to 360 seconds.
4. Title: keep the spec's, or a new one.
5. Weirdness (0 to 1), style influence (0 to 1) and variety (whole number 0 to 4): Suno default, low, medium, high, or an exact value. Use low 0.2, medium 0.5, high 0.8 for the two sliders, and 1, 2, 3 for variety. "Suno default" means leave it out. Never send 0 as a stand-in for "unset".
6. Excluded styles (the negative style): none, keep the spec's, or a list. These only work when there is Style text.
7. Model: the plan default, or one of v6-mini, v6, v6-wild. Check the choice against `allowed_models` from `account-usage`.

Ask about Max mode only if the user mentions it or the spec sets `max_mode: true`. It spends a multiple of the usual credits, so the user must confirm it by name.

If they choose "Suggest settings for me", read the Style, Lyrics excerpt and Idea, propose values for weirdness, style influence, variety, vocal gender, duration and excluded styles with one short reason each, and ask whether to use them or change any. Do not apply them without a yes.

A value the user gives replaces the spec's value. An empty value means "leave it out so Suno uses its default."

## 4. Build the request

- title: the setting or the user's choice
- style: the Style section exactly as written
- lyrics: the Lyrics section exactly as written, `[section]` tags included
- negative_style: from the user or the Negative style section, only when Style is not empty
- instrumental, model, voice_id, vocal_gender, duration: the settings of the same name, or the user's choice
- controls: weirdness, style_influence, variety, audio_influence, sent only when set
- max_mode: only if on and confirmed

BPM and key go in the prompt text, not as Suno options, for songs and covers. If the Style does not already mention the bpm and key, add them to the end (for example ", 89 BPM, Ab minor") as long as it stays within 1000 characters. If the user changed the tempo or key, replace the spec's old values in the Style as well. For a loop, add them to the description (within 500 characters) and also send `tempo` and `key` (use sharps, for example `A#m`). Tell the user about every change you make.

No lyrics: if the Lyrics section is empty and `instrumental` is not true, send the Style alone, with no lyrics and without setting `instrumental`, and say so. If Suno rejects a request without lyrics, stop and tell the user what Suno said; do not write lyrics or switch to instrumental yourself. If `instrumental` is true and lyrics exist, ask which to keep.

Checks. Stop with a clear message if any fails: title 256 characters or fewer, style 1000, lyrics 5000, negative_style 1000, loop description 1 to 500; weirdness, style_influence, audio_influence between 0 and 1; variety a whole number 0 to 4; duration a whole number 15 to 360; vocal_gender only male or female and not with a voice_id; audio_influence on a new song only with a voice_id.

Covers have no instrumental or vocal_gender option. Say so if the user set either.

## 5. Show the exact request and wait

Before calling Suno, show: which tool, every field you will send (Style and Lyrics in full, in code blocks), the settings left to Suno's defaults, anything you changed, and what was withheld by rule. Say that it uses credits and makes 2 results (about 1 credit per loop; the song cost is not fixed, and Max mode costs more). Mention the credits left from `account-usage`. Ask the user to confirm. Do not send until they say yes.

## 6. Send and show the results

Call the tool with an `idempotency_key`. Then call `audio-wait` once, with both clip IDs in `ids`, so the chat shows one player for both versions. If one is still pending, call `audio-wait` again. Do not poll with `audio-retrieve` while `audio-wait` works.

Then give the user, for each version: title, clip ID, the song link, and the cover art link from `audio-retrieve` if it is available. Mention any difference between the two versions that matters. Offer a next step only if there is a real one, such as analysis, stems or a cover.

If a request fails, say what Suno said. Do not retry automatically, because a failed request may still have been accepted. Check the library first.
